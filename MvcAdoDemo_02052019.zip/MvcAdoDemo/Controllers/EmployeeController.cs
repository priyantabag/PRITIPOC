using System;  
using System.Collections.Generic;  
using System.Diagnostics;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using MVCAdoDemo.Models;  
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.Data.SqlClient;
using OfficeOpenXml;

namespace MVCAdoDemo.Controllers  
{  
    public class EmployeeController : Controller  
    {  
         private readonly IHostingEnvironment _hostingEnvironment;
        public EmployeeController(IHostingEnvironment hostingEnvironment) 
        {
             _hostingEnvironment = hostingEnvironment;
          }
        EmployeeDataAccessLayer objemployee = new EmployeeDataAccessLayer();  
        
           
      
        public IActionResult Index()  
        {  
            List<Employee> lstEmployee = new List<Employee>();  
            lstEmployee = objemployee.GetAllEmployees().ToList();  
            return View(lstEmployee);  
        }  
        [HttpGet]
        public IActionResult Import()
        {
            return View();
        }
        /*[HttpGet]  
        public IActionResult Create()  
        {  
            return View();  
        }   */
      
       // [HttpPost]  
       //[ValidateAntiForgeryToken]  
       /* public IActionResult Create([Bind] Employee employee)  
        {  
            if (ModelState.IsValid)  
            {  
                objemployee.AddEmployee(employee);  
                return RedirectToAction("Index");  
            }  
            return View(employee);  
        }   */
        [HttpGet]    
        public IActionResult Edit(int? id)    
        {    
            if (id == null)    
            {    
                return NotFound();    
            }    
            Employee employee = objemployee.GetEmployeeData(id);    
            if (employee == null)    
            {    
                return NotFound();    
            }    
            return View(employee);    
        }    
  
        [HttpPost]    
        [ValidateAntiForgeryToken]    
        public IActionResult Edit(int id, [Bind]Employee employee)    
        {    
            if (id != employee.ID)    
            {    
                return NotFound();    
            }    
            if (ModelState.IsValid)    
            {    
                objemployee.UpdateEmployee(employee);    
                return RedirectToAction("Index");    
            }    
            return View(employee);    
        }  
        [HttpGet]  
        public IActionResult Details(int? id)  
        {  
            if (id == null)  
            {  
                return NotFound();  
            }  
            Employee employee = objemployee.GetEmployeeData(id);  
        
            if (employee == null)  
            {  
                return NotFound();  
            }  
            return View(employee);  
        }   
        [HttpGet]  
        public IActionResult Delete(int? id)  
        {  
            if (id == null)  
            {  
                return NotFound();  
            }  
            Employee employee = objemployee.GetEmployeeData(id);  
        
            if (employee == null)  
            {  
                return NotFound();  
            }  
            return View(employee);  
        }  
      
        [HttpPost, ActionName("Delete")]  
        [ValidateAntiForgeryToken]  
        public IActionResult DeleteConfirmed(int? id)  
        {  
            objemployee.DeleteEmployee(id);  
            return RedirectToAction("Index");  
        }  

//[HttpPost("UploadFiles")]
public async Task<IActionResult> UploadFiles(List<IFormFile> files)
{
    
    long size = files.Sum(f => f.Length);
     string rootPath=_hostingEnvironment.WebRootPath;
    // Full path to file in temp location
    string filePath = rootPath+"\\"+ "Values1.xlsx";

    foreach (var formFile in files)
    {
        string path=formFile.FileName;
        if (formFile.Length > 0)
            using (var stream = new FileStream(filePath, FileMode.Create))
                await formFile.CopyToAsync(stream);
    }
            System.Data.DataTable table = new System.Data.DataTable();
            FileInfo file = new FileInfo(Path.Combine(rootPath +"\\", "Values1.xlsx"));  
            ExcelPackage package = new ExcelPackage(file);
            ExcelWorksheet workSheet = package.Workbook.Worksheets.First();
            
            foreach (var firstRowCell in workSheet.Cells[1, 1, 1, workSheet.Dimension.End.Column])
            {
                table.Columns.Add(firstRowCell.Text);
            }
            for (var rowNumber = 2; rowNumber <= workSheet.Dimension.End.Row; rowNumber++)
            {
                var row = workSheet.Cells[rowNumber, 1, rowNumber, workSheet.Dimension.End.Column];
                var newRow = table.NewRow();
                foreach (var cell in row)
                {
                    newRow[cell.Start.Column - 1] = cell.Text;
                }
                table.Rows.Add(newRow);
            }
                    
            if (table.Rows.Count > 0)
             {
                string connectionString = "Data Source=PRIYANTA\\SQLEXPRESS;Initial Catalog=DGVDB;Integrated Security=SSPI;User ID=sa;Password=root";    
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    
                using (var cmd = con.CreateCommand())
                {
                   con.Open();
                   cmd.CommandText = "DELETE FROM dbo.Values1";
                   cmd.ExecuteNonQuery();
                   con.Close();
                }
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name
                        sqlBulkCopy.DestinationTableName = $"{"dbo"}.[{"Values1"}]";//"dbo.Values";
        
                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("Id", "Id");
                        sqlBulkCopy.ColumnMappings.Add("Description", "Description");
                        sqlBulkCopy.ColumnMappings.Add("Title", "Title");
                        con.Open();
                        sqlBulkCopy.WriteToServer(table);
                        con.Close();
                    }
                }
            }
     //test(filePath);

    //wbWorkbook.Close(false, "", true);

   // System.Data.DataTable dt=GetSheetDataAsDataTable(filePath);
   // System.Data.DataTable dt=READExcel(filePath);

    // Process uploaded files
    return RedirectToAction("Index");  
    //return Ok(new { count = files.Count, path = filePath});
}
            
    }  
}  
