﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MvcAdoDemo.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Data;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop;
using System.Runtime.InteropServices;
//using Microsoft.Office.Interop.Excel;
namespace MvcAdoDemo.Controllers
{
    public class HomeController : Controller
    {
    
        public IActionResult Index()
        {
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application(); 
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook =xlApp.Workbooks.Open(@"F:\test3.xlsx");
        Microsoft.Office.Interop.Excel._Worksheet xlWorksheet = (Microsoft.Office.Interop.Excel._Worksheet)xlWorkBook.Sheets[1];
        if(xlWorksheet != null)
        {
                 Microsoft.Office.Interop.Excel.Range xlRange = xlWorksheet.UsedRange;
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
        }
       
      // Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet ;
        //Microsoft.Office.Interop.Excel.Range range ; 
       
           /* Microsoft.Office.Interop.Excel.Application xlApp ; 
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook ;
        Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet ;
        Microsoft.Office.Interop.Excel.Range range ; 
        string str; 
        int rCnt ; 
        int cCnt ; 
        int rw = 0; 
        int cl = 0; 
        xlApp = new Microsoft.Office.Interop.Excel.Application(); 
        xlWorkBook = xlApp.Workbooks.Open(@"F:\test3.xlsx");//, 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
        xlApp.Wait(100);
        xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.ActiveSheet;//(Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets[1];//.get_Item(1);
        xlApp.Wait(100);
        //xlWorkSheet.Visible=XlSheetVisibility.xlSheetVisible;
        range = xlWorkSheet.UsedRange;
        rw = range.Rows.Count;
        cl = range.Columns.Count; 
        for (rCnt = 1; rCnt <= rw; rCnt++) 
        { 
            for (cCnt = 1; cCnt <= cl; cCnt++) 
            { 
                str = (string)(range.Cells[rCnt, cCnt] as Microsoft.Office.Interop.Excel.Range).Value2;
            } 
        }
        xlWorkBook.Close(true, null, null); 
        xlApp.Quit();*/

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
         public ActionResult ModalPopUp()  
        {  
            return View();  
        }  
[HttpPost("UploadFiles")]
public async Task<IActionResult> Post(List<IFormFile> files)
{
    
    long size = files.Sum(f => f.Length);

    // Full path to file in temp location
    string filePath = "F:\\VSCODE\\MvcAdoDemo\\text.xlsx";

    foreach (var formFile in files)
    {
        string path=formFile.FileName;
        if (formFile.Length > 0)
            using (var stream = new FileStream(filePath, FileMode.Create))
                await formFile.CopyToAsync(stream);
    }
     
     test(filePath);

    //wbWorkbook.Close(false, "", true);

   // System.Data.DataTable dt=GetSheetDataAsDataTable(filePath);
   // System.Data.DataTable dt=READExcel(filePath);

    // Process uploaded files

    return Ok(new { count = files.Count, path = filePath});
}

public void test(string filePath)
{
        Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application(); 
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook =xlApp.Workbooks.Open(@"F:\test3.xlsx");
        Microsoft.Office.Interop.Excel._Worksheet xlWorksheet = (Microsoft.Office.Interop.Excel._Worksheet)xlWorkBook.Sheets[1];
       // Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet ;
        //Microsoft.Office.Interop.Excel.Range range ; 
        Microsoft.Office.Interop.Excel.Range xlRange = xlWorksheet.UsedRange;

            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
        string str; 
        int rCnt ; 
        int cCnt ; 
        int rw = 0; 
        int cl = 0; 
        xlApp = new Microsoft.Office.Interop.Excel.Application(); 
        xlWorkBook = xlApp.Workbooks.Open(@"F:\test3.xlsx", 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
        //xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        //int colCount = xlWorkSheet.Dimension.End.Column;  //get Column Count
        //int rowCount = xlWorkSheet.Dimension.End.Row; 
       // range = xlWorkSheet.UsedRange;
        /*rw = range.Rows.Count;
        cl = range.Columns.Count; 
        for (rCnt = 1; rCnt <= rw; rCnt++) 
        { 
            for (cCnt = 1; cCnt <= cl; cCnt++) 
            { 
                str = (string)(range.Cells[rCnt, cCnt] as Microsoft.Office.Interop.Excel.Range).Value2;
            } 
        }
        xlWorkBook.Close(true, null, null); 
        xlApp.Quit(); */
   /*Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                    excel.Visible = false;
                    Microsoft.Office.Interop.Excel.Workbook xlWorkbook = excel.Workbooks.Open(@"F:\test3.xlsx", CorruptLoad: true);
 int worksheetcount = xlWorkbook.Worksheets.Count;
                    Microsoft.Office.Interop.Excel._Worksheet wks = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkbook.Sheets[1];
                    string firstworksheetname = wks.Name;
                    Microsoft.Office.Interop.Excel._Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)excel.ActiveSheet;
                   Microsoft.Office.Interop.Excel.Range usedRange =  wks.UsedRange;
                   int lastRow = workSheet.Cells.SpecialCells(XlCellType.xlCellTypeLastCell, Type.Missing).Row;
                   foreach(Microsoft.Office.Interop.Excel.Range row in usedRange.Rows)
                        {
                            //Do something with the row.

                            //Ex. Iterate through the row's data and put in a string array
                            String[] rowData = new String[row.Columns.Count];
                            for(int i = 0; i < row.Columns.Count; i++)
                                rowData[i] = Convert.ToString(((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[1,i+1]).Value2); 
                                //((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[1, i + 1].Value2;
                        }
                    var firstcellvalue = ((Microsoft.Office.Interop.Excel.Range)workSheet.Columns[1]).AutoFit(); */
}
    

public static System.Data.DataTable READExcel(string path)

        {

            //Instance reference for Excel Application

            Microsoft.Office.Interop.Excel.Application objXL = null;

            //Workbook refrence

            Microsoft.Office.Interop.Excel.Workbook objWB = null;

            DataSet ds = new DataSet();
            System.Data.DataTable dt = new System.Data.DataTable();

            try

            {

                //Instancing Excel using COM services

                objXL = new Microsoft.Office.Interop.Excel.Application();

                //Adding WorkBook

                objWB = objXL.Workbooks.Open(path);

 

                foreach (Microsoft.Office.Interop.Excel.Worksheet objSHT in objWB.Worksheets)
                {

                    int rows = objSHT.UsedRange.Rows.Count;

                    int cols = objSHT.UsedRange.Columns.Count;

                    

                    int noofrow = 1;

 

                    //If 1st Row Contains unique Headers for datatable include this part else remove it

                    //Start

                    for (int c = 1; c <= cols; c++)

                    {

                        string colname = objSHT.Cells[1, c].ToString();

                        dt.Columns.Add(colname);

                        noofrow = 2;

                    }

                    //END

 

                    for (int r = noofrow; r <= rows; r++)

                    {

                        DataRow dr = dt.NewRow();

                        for (int c = 1; c <= cols; c++)

                        {

                            dr[c - 1] = objSHT.Cells[r, c].ToString();

                        }

                        dt.Rows.Add(dr);

                    }

                    ds.Tables.Add(dt);

                   

                }

 

                //Closing workbook

                objWB.Close();

                //Closing excel application

                objXL.Quit();

 

            }

            catch (Exception ex)

            {

                objWB.Saved = true;

                //Closing work book

                objWB.Close();

                //Closing excel application

                objXL.Quit();

                //Response.Write("Illegal permission");

            }
            return dt;

        }

 

        
    public System.Data.DataTable GetSheetDataAsDataTable(string filePath)
    {
        Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
        //xlApp.Visible=true;
        Microsoft.Office.Interop.Excel.Workbook xlBook = null;
        Microsoft.Office.Interop.Excel.Range xlRange;
        Microsoft.Office.Interop.Excel.Worksheet xlSheet;
        System.Data.DataTable result= new System.Data.DataTable();
        System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                //var app = new Application { Visible = true };
                //app.Workbooks.Add();
                //Microsoft.Office.Interop.Excel.Worksheet xlWSheet = app.ActiveSheet;
                
                xlBook = xlApp.Workbooks.Open(filePath);
                xlSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlBook.Worksheets["Sheet1"];
                xlRange = xlSheet.UsedRange.SpecialCells(Microsoft.Office.Interop.Excel.XlCellType.xlCellTypeLastCell,Type.Missing);
                DataRow row=null;
                for (int i = 1; i <= xlRange.Rows.Count; i++)
                {
                    if (i != 1)
                        row = dt.NewRow();
                    for (int j = 1; j <= xlRange.Columns.Count; j++)
                    {
                        if (i == 1)
                        {
                                string str=Convert.ToString(((Microsoft.Office.Interop.Excel.Range)xlSheet.Cells[1, j]).Value2);
                                dt.Columns.Add(str);
                        }
                        
                            //dt.Columns.Add(((Microsoft.Office.Interop.Excel.Range)xlRange.Cells[1, j]).Value2);
                        else
                            row[j-1] = ((Microsoft.Office.Interop.Excel.Range)xlSheet.Cells[i,j]).Value2; //xlRange.Cells[i, j].()value;
                    }
                    if(row !=null)
                        dt.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                xlBook.Close();
                xlApp.Quit();
            }
            return dt;
    }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        
    }
}
